
const taskForm = document.querySelector("#taskForm");
const taskInput = document.querySelector("#taskInput");
const taskError = document.querySelector("#taskError");
const taskList = document.querySelector("#taskList");
const totalTasks = document.querySelector("#totalTasks");
const remainingTasks = document.querySelector("#remainingTasks");
const clearCompletedButton =
    document.querySelector("#clearCompleted");
const filterButtons =
    document.querySelectorAll(".filter");
let currentFilter = "all";
taskForm.addEventListener("submit", function (event) {
    event.preventDefault();
    const taskText = taskInput.value.trim();
    taskError.textContent = "";
    if (taskText === "") {
        taskError.textContent =
            "Please enter a task.";
        taskInput.focus();
        return;
    }
    const tasks =
        taskList.querySelectorAll(".task");
    for (let task of tasks) {
        const existingText =
            task.querySelector(".task-text")
                .textContent
                .trim()
                .toLowerCase();
        if (existingText === taskText.toLowerCase()) {
            taskError.textContent =
                "This task already exists.";
            taskInput.focus();
            return;
        }
    }
    const li = document.createElement("li");
    li.classList.add("task");
    const checkbox =
        document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.classList.add("complete-checkbox");
    const span =
        document.createElement("span");
    span.classList.add("task-text");
    span.textContent = taskText;
    const deleteButton =
        document.createElement("button");
    deleteButton.type = "button";
    deleteButton.classList.add("delete-button");
    deleteButton.textContent = "Delete";
    li.appendChild(checkbox);
    li.appendChild(span);
    li.appendChild(deleteButton);
    taskList.appendChild(li);
    taskInput.value = "";
    taskInput.focus();
    updateCounter();
    applyFilter();
});
taskList.addEventListener("click", function (event) {
    if (
        event.target.classList.contains(
            "delete-button"
        )
    ) {
        const task =
            event.target.closest(".task");
        task.remove();
        updateCounter();
        return;
    }
    if (
        event.target.classList.contains(
            "task-text"
        )
    ) {
        startEditing(event.target);
    }
});
taskList.addEventListener("change", function (event) {
    if (
        event.target.classList.contains(
            "complete-checkbox"
        )
    ) {
        const task =
            event.target.closest(".task");
        task.classList.toggle(
            "completed",
            event.target.checked
        );
        updateCounter();
        applyFilter();
    }
});
function updateCounter() {
    const tasks =
        taskList.querySelectorAll(".task");
    const total = tasks.length;
    let remaining = 0;
    tasks.forEach(function (task) {
        const checkbox =
            task.querySelector(
                ".complete-checkbox"
            );
        if (!checkbox.checked) {
            remaining++;
        }
    });
    totalTasks.textContent =
        "Total: " + total;
    remainingTasks.textContent =
        "Remaining: " + remaining;
}
filterButtons.forEach(function (button) {
    button.addEventListener("click", function () {
        filterButtons.forEach(function (btn) {
            btn.classList.remove("active");
        });
        button.classList.add("active");
        currentFilter =
            button.dataset.filter;
        applyFilter();
    });
});
function applyFilter() {
    const tasks =
        taskList.querySelectorAll(".task");
    tasks.forEach(function (task) {
        const checkbox =
            task.querySelector(
                ".complete-checkbox"
            );
        const completed =
            checkbox.checked;
        if (currentFilter === "all") {
            task.style.display = "flex";

        }
        else if (
            currentFilter === "active"
        ) {
            if (completed) {
                task.style.display = "none";
            } else {
                task.style.display = "flex";
            }
        }
        else if (
            currentFilter === "completed"
        ) {
            if (completed) {
                task.style.display = "flex";
            } else {
                task.style.display = "none";
            }
        }
    });
}
clearCompletedButton.addEventListener(
    "click",
    function () {
        const tasks =
            taskList.querySelectorAll(".task");
        tasks.forEach(function (task) {
            const checkbox =
                task.querySelector(
                    ".complete-checkbox"
                );
            if (checkbox.checked) {
                task.remove();
            }
        });
        updateCounter();
        applyFilter();
    }
);
function startEditing(span) {
    if (span.querySelector(".edit-input")) {
        return;
    }
    const oldText =
        span.textContent;
    const input =
        document.createElement("input");
    input.type = "text";
    input.classList.add("edit-input");
    input.value = oldText;
    span.textContent = "";
    span.appendChild(input);
    input.focus();
    input.select();
    input.addEventListener(
        "keydown",
        function (event) {
            if (event.key === "Enter") {
                saveEdit(span, input);
            }
            if (event.key === "Escape") {
                cancelEdit(span, oldText);

            }
        }
    );
}
function saveEdit(span, input) {
    const newText =
        input.value.trim();
    if (newText === "") {
        taskError.textContent =
            "Task cannot be empty.";
        cancelEdit(
            span,
            "Previous task"
        );
        return;
    }
    const tasks =
        taskList.querySelectorAll(".task");
    for (let task of tasks) {
        const otherSpan =
            task.querySelector(
                ".task-text"
            );
        if (otherSpan === span) {
            continue;
        }
        if (
            otherSpan.textContent
                .trim()
                .toLowerCase()
            === newText.toLowerCase()
        ) {
            taskError.textContent =
                "This task already exists.";
            return;
        }
    }
    span.textContent = newText;
    taskError.textContent = "";
}
function cancelEdit(span, oldText) {
    span.textContent = oldText;
}
